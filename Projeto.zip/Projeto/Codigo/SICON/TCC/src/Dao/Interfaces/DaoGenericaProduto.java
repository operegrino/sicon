/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.produto;

/**
 *
 * @author jonathan
 */
public interface DaoGenericaProduto extends DaoGenerica<produto>{

}
