/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.dadosbancarios;

/**
 *
 * @author Jonathan
 */
public interface DaoGenericaDadosBancarios extends DaoGenerica<dadosbancarios>{

}
