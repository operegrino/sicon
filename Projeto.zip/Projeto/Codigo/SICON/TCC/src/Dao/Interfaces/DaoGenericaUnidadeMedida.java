/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.unidademedida;

/**
 *
 * @author Jonathan
 */
public interface DaoGenericaUnidadeMedida extends DaoGenerica<unidademedida>{

}
