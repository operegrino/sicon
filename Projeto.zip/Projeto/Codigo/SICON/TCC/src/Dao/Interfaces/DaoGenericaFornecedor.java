/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.fornecedor;

/**
 *
 * @author Jonathan
 */
public interface DaoGenericaFornecedor extends DaoGenerica<fornecedor>{

}
