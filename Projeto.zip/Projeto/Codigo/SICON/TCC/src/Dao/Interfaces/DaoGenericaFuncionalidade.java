/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.botao;

/**
 *
 * @author Jonathan
 */
public interface DaoGenericaFuncionalidade extends DaoGenerica<botao>{

}
