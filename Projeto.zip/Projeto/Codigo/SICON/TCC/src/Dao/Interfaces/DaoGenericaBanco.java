/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.banco;

/**
 *
 * @author Jonathan
 */
public interface DaoGenericaBanco extends DaoGenerica<banco>{

}
