/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao.Interfaces;

import Classes.operacao;

/**
 *
 * @author Jonathan
 */
public interface DaoGenericaOperacao extends DaoGenerica<operacao>{

}
