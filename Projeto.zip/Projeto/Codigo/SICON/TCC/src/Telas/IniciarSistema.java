/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas;

/**
 *
 * @author Jonathan
 */
public class IniciarSistema {
    
    public static void main(String args[]) {
        TelaLogin telaLogin = new TelaLogin();
        telaLogin.setVisible(true);
    }

}
