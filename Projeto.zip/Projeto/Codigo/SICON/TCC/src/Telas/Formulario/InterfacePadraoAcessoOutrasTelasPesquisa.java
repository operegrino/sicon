/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas.Formulario;

/**
 *
 * @author    jonathan
 * @Objetivo: Quando a tela possuir botões que abrem outra tela na tela de pesquisa
 *            deverá ser implementada está interface; 
 */
public interface InterfacePadraoAcessoOutrasTelasPesquisa extends InterfacePadraoTela{
    
    public void setComponenteTable(boolean Acesso);

}
